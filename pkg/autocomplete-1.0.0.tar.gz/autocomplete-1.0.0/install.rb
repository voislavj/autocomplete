# Install hook code here
#require 'ftools'
#
#plugins_dir = File.expand_path(".")
#autocomplete_dir = File.join(plugins_dir, 'autocomplete')
#root_dir = File.join(autocomplete_dir, '..', '..', '..')
#
#File.copy File.join(autocomplete_dir, 'assets', 'autocomplete.js'), File.join(root_dir, 'public', 'javascripts', 'autocomplete.js')
#File.copy File.join(autocomplete_dir, 'assets', 'autocomplete.css'), File.join(root_dir, 'public', 'stylesheets', 'autocomplete.css')
#File.copy File.join(autocomplete_dir, 'assets', 'autocomplete-loading.gif'), File.join(root_dir, 'public', 'images', 'autocomplete-loading.gif')
