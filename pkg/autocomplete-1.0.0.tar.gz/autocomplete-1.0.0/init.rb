# Include hook code here
require 'autocomplete_controller'
require 'autocomplete_helper'

ActionView::Base.send(:include, AutocompleteHelper)